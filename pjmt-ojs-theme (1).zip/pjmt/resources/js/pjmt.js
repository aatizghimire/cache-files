(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var toggle = document.querySelector('.pjmt-nav-toggle');
		var nav = document.querySelector('.pjmt-primary-nav');
		var search = document.querySelector('.pjmt-search');

		if (toggle && nav) {
			toggle.addEventListener('click', function () {
				nav.classList.toggle('is-open');
				if (search) {
					search.classList.toggle('is-open');
				}
				var expanded = nav.classList.contains('is-open');
				toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
			});
		}
	});
})();
