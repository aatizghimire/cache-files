<?php

/**
 * @defgroup plugins_themes_pjmt PJMT Theme Plugin
 */

/**
 * @file plugins/themes/pjmt/index.php
 *
 * Copyright (c) 2026 Presidential Graduate School
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @ingroup plugins_themes_pjmt
 * @brief Wrapper for the PJMT theme plugin.
 */

require_once('PjmtThemePlugin.php');

return new APP\plugins\themes\pjmt\PjmtThemePlugin();
