{**
 * templates/frontend/components/footer.tpl
 *
 * PJMT theme footer override. Four columns: journal identity, indexing
 * services, quick links (About/Submission pages) and contact details.
 * All content is pulled from Website Settings so nothing is hard-coded
 * per-journal except the section labels themselves.
 *}
{call_hook name="Templates::Common::Footer::PageFooter"}

<footer class="pjmt-footer" role="contentinfo">
	<div class="pjmt-footer-inner">
		<div class="pjmt-footer-col">
			<h4>{if $currentContext}{$currentContext->getLocalizedAcronym()|default:$currentContext->getLocalizedName()|escape}{else}{translate key="common.software"}{/if}</h4>
			{if $currentContext}
				<p>{$currentContext->getLocalizedName()|escape}</p>
			{/if}
			{if $currentContext && $currentContext->getData('mailingAddress')}
				<p>{$currentContext->getData('mailingAddress')|nl2br}</p>
			{/if}
		</div>

		<div class="pjmt-footer-col">
			<h4>{translate key="plugins.themes.pjmt.footer.indexedIn" default="Indexed in"}</h4>
			{* Edit this list to match where your journal is actually indexed. *}
			<ul>
				<li><a href="https://doaj.org" target="_blank" rel="noopener noreferrer">DOAJ</a></li>
				<li><a href="https://www.crossref.org" target="_blank" rel="noopener noreferrer">Crossref</a></li>
				<li><a href="https://scholar.google.com" target="_blank" rel="noopener noreferrer">Google Scholar</a></li>
				<li><a href="https://www.nepjol.info" target="_blank" rel="noopener noreferrer">NepJOL</a></li>
			</ul>
		</div>

		<div class="pjmt-footer-col">
			<h4>{translate key="plugins.themes.pjmt.footer.quickLinks" default="Quick links"}</h4>
			<ul>
				{if $currentContext}
					<li><a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="editorialPolicies"}">{translate key="about.editorialPolicies"}</a></li>
					<li><a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="submissions"}">{translate key="about.submissions"}</a></li>
					<li><a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="editorialTeam"}">{translate key="about.editorialTeam"}</a></li>
					<li><a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about"}">{translate key="navigation.about"}</a></li>
				{/if}
			</ul>
		</div>

		<div class="pjmt-footer-col">
			<h4>{translate key="common.contact"|default="Contact"}</h4>
			{if $currentContext && $currentContext->getData('supportEmail')}
				<p><a href="mailto:{$currentContext->getData('supportEmail')|escape}">{$currentContext->getData('supportEmail')|escape}</a></p>
			{/if}
			{if $currentContext && $currentContext->getData('licenseTerms')}
				<p>{$currentContext->getData('licenseTerms')|strip_tags}</p>
			{/if}
		</div>
	</div>

	<div class="pjmt-footer-bottom">
		&copy; {$smarty.now|date_format:"%Y"} {if $currentContext}{$currentContext->getLocalizedAcronym()|default:$currentContext->getLocalizedName()|escape}{else}{translate key="common.software"}{/if}
		&mdash; {translate key="plugins.themes.pjmt.footer.poweredBy" default="Powered by Open Journal Systems"}
	</div>
</footer>
