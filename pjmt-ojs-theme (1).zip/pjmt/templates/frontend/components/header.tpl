{**
 * templates/frontend/components/header.tpl
 *
 * PJMT theme header override.
 * Renders a two-tier header: a slim utility bar (ISSN + login) and the
 * main navigation bar (logo, primary nav, search). Falls back gracefully
 * if a journal has not set eISSN/pISSN or a homepage logo.
 *}
{assign var="hasEissn" value=$currentContext->getData('onlineIssn')|default:''}
{assign var="hasPissn" value=$currentContext->getData('printIssn')|default:''}

<a class="skip-link screen-reader-only" href="#pjmt-content">{translate key="navigation.skip.main"}</a>

{call_hook name="Templates::Common::Header::PageHeader"}

<div class="pjmt-topbar">
	<div class="pjmt-topbar-inner">
		{if $hasEissn}
			<span class="pjmt-topbar-issn"><strong>eISSN</strong> {$hasEissn|escape}</span>
		{/if}
		{if $hasPissn}
			<span class="pjmt-topbar-issn"><strong>pISSN</strong> {$hasPissn|escape}</span>
		{/if}
		{if $isUserLoggedIn}
			<a class="pjmt-login" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="user" op="profile"}">
				{translate key="navigation.myAccount"}
			</a>
			<a class="pjmt-login" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="login" op="signOut"}">
				{translate key="user.logOut"}
			</a>
		{else}
			<a class="pjmt-login" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="login"}">
				{translate key="navigation.login"}
			</a>
		{/if}
	</div>
</div>

<header class="pjmt-navbar" role="banner">
	<div class="pjmt-navbar-inner">
		<a class="pjmt-logo" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="index"}">
			{assign var="pjmtLogoImage" value=$currentContext->getLocalizedData('pageHeaderLogoImage')|default:false}
			{if $pjmtLogoImage}
				<img src="{$publicFilesDir}/{$pjmtLogoImage.uploadName|escape}" alt="{$pjmtLogoImage.altText|default:$currentContext->getLocalizedName()|escape}">
			{else}
				{* Falls back to the theme's bundled Presidential Graduate School mark until a
				   journal logo is uploaded under Website Settings > Appearance > Setup. *}
				<img src="{$baseUrl}/{$pjmtPluginPath}/assets/logo.png" alt="{if $currentContext}{$currentContext->getLocalizedName()|escape}{else}{translate key="common.software"}{/if}">
			{/if}
			<span class="pjmt-logo-text">
				<span class="p1">{if $currentContext}{$currentContext->getLocalizedAcronym()|default:$currentContext->getLocalizedName()|escape}{else}{translate key="common.software"}{/if}</span>
			</span>
		</a>

		<button type="button" class="pjmt-nav-toggle" aria-expanded="false" aria-controls="pjmt-primary-nav" aria-label="{translate key='navigation.navMenu'|default:'Menu'}">
			&#9776;
		</button>

		<nav class="pjmt-primary-nav" id="pjmt-primary-nav" aria-label="{translate key='navigation.navMenu'|default:'Primary'}">
			<ul>
				{if $primaryNavigationMenu}
					{foreach from=$primaryNavigationMenu->getMenuTree() item=item}
						<li class="{if $item->getIsChildVisible()}has-submenu{/if}{pjmt_item_active item=$item}">
							<a href="{$item->getUrl()}" {if $item->getIsChildVisible()}target="{$item->getTarget()|escape}"{/if}>
								{$item->getTitle()|escape}
							</a>
						</li>
					{/foreach}
				{/if}
			</ul>
		</nav>

		<form class="pjmt-search" role="search" action="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="search" op="search"}" method="get">
			<label class="screen-reader-only" for="pjmt-search-query">{translate key="common.search"}</label>
			<input type="search" id="pjmt-search-query" name="query" placeholder="{translate key='common.search'}...">
			<button type="submit" aria-label="{translate key='common.search'}">&#128269;</button>
		</form>
	</div>
</header>

{call_hook name="Templates::Common::Header::Navbar"}
