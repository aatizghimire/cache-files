{**
 * templates/frontend/pages/indexJournal.tpl
 *
 * PJMT theme homepage: hero image, intro blurb, and a three-column layout
 * (Current Issue + News | Latest Articles | Submit/Review CTAs + Journal
 * Menu + Editorial Board). Data for pjmtCurrentIssue / pjmtOlderIssues /
 * pjmtLatestArticles is assigned by PjmtThemePlugin::addPjmtTemplateData().
 *}
{include file="frontend/components/header.tpl" pageTitle="common.journalHomepageTitle"}

<main id="pjmt-content" class="pjmt-home">

	{if $currentContext->getLocalizedData('homepageImage')}
		<div class="pjmt-hero">
			<img src="{$publicFilesDir}/{$currentContext->getLocalizedData('homepageImage').uploadName|escape}"
				alt="{$currentContext->getLocalizedData('homepageImage').altText|default:$currentContext->getLocalizedName()|escape}">
		</div>
	{/if}

	<div class="pjmt-home-grid">

		{* ---------------- Left column: current issue + news ---------------- *}
		<aside class="pjmt-left-col">
			{if $pjmtCurrentIssue}
				<div class="pjmt-card">
					<h3>{translate key="issue.currentIssue"}</h3>
					{if $pjmtCurrentIssue->getLocalizedCoverImageUrl($currentContext->getId())}
						<img class="pjmt-current-issue-cover"
							src="{$pjmtCurrentIssue->getLocalizedCoverImageUrl($currentContext->getId())|escape}"
							alt="{$pjmtCurrentIssue->getLocalizedTitle()|escape}">
					{/if}
					<a class="pjmt-current-issue-title" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="issue" op="view" path=$pjmtCurrentIssue->getBestIssueId()}">
						{$pjmtCurrentIssue->getIssueIdentification()|escape}
					</a>
					<span class="pjmt-current-issue-date">
						{translate key="common.published"} {$pjmtCurrentIssue->getDatePublished()|date_format:"%-d %B %Y"}
					</span>
					<a class="pjmt-view-issue" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="issue" op="view" path=$pjmtCurrentIssue->getBestIssueId()}">
						{translate key="plugins.themes.pjmt.viewIssue" default="View current issue"} &rarr;
					</a>
				</div>
			{/if}

			{if $announcements}
				<div class="pjmt-card">
					<h3>{translate key="announcement.announcements"}</h3>
					{foreach from=$announcements item=announcement}
						<div class="pjmt-news-item">
							<a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="announcement" op="view" path=$announcement->getId()}">
								{$announcement->getLocalizedTitle()|escape|truncate:70}
							</a>
							<span class="pjmt-news-date">{$announcement->getDatePosted()|date_format:"%-d %B %Y"}</span>
						</div>
					{/foreach}
				</div>
			{/if}
		</aside>

		{* ---------------- Center column: intro + latest articles ---------------- *}
		<div class="pjmt-center-col">
			<div class="pjmt-intro">
				<h2>{translate key="plugins.themes.pjmt.tagline" default="Lead. Inspire. Innovate."}</h2>
				<p>{$currentContext->getLocalizedDescription()|strip_tags|default:$currentContext->getLocalizedData('journalDescription')|strip_tags}</p>
				<a class="pjmt-learn-more" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about"}">
					{translate key="plugins.themes.pjmt.learnMore" default="Learn more about"} {$currentContext->getLocalizedAcronym()|default:$currentContext->getLocalizedName()|escape} &rarr;
				</a>
			</div>

			{if $pjmtLatestArticles}
				<div class="pjmt-section-heading">
					<h3>{translate key="plugins.themes.pjmt.latestArticles" default="Latest Articles"}</h3>
					<a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="issue" op="archive"}">{translate key="common.viewAll"|default="View all"}</a>
				</div>

				{foreach from=$pjmtLatestArticles item=entry}
					{assign var="pub" value=$entry.publication}
					{assign var="sub" value=$entry.submission}
					<article class="pjmt-article-row">
						{if $entry.sectionTitle}
							<span class="pjmt-tag pjmt-tag--{$entry.sectionTitle|lower|replace:' ':'-'}">{$entry.sectionTitle|escape}</span>
						{/if}
						<h4>
							<a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="article" op="view" path=$entry.urlPath}">
								{$pub->getLocalizedFullTitle()|strip_tags}
							</a>
						</h4>
						{if $entry.authorString}
							<div class="pjmt-article-authors">{$entry.authorString|escape}</div>
						{/if}
						<div class="pjmt-article-meta">
							{if $pub->getData('pages')}<span>pp. {$pub->getData('pages')|escape}</span>{/if}
							{if $pub->getStoredPubId('doi')}
								<a class="pjmt-doi" href="https://doi.org/{$pub->getStoredPubId('doi')|escape}" target="_blank" rel="noopener noreferrer">
									https://doi.org/{$pub->getStoredPubId('doi')|escape}
								</a>
							{/if}
						</div>
						<div class="pjmt-article-actions">
							<a class="pjmt-btn-sm pjmt-btn-sm--outline" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="article" op="view" path=$entry.urlPath}">
								{translate key="submission.abstract"}
							</a>
							<a class="pjmt-btn-sm pjmt-btn-sm--solid" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="article" op="view" path=$entry.urlPath}">
								PDF
							</a>
						</div>
					</article>
				{/foreach}
			{/if}
		</div>

		{* ---------------- Right column: CTAs, menu, editorial board ---------------- *}
		<aside class="pjmt-right-col">
			<a class="pjmt-cta-btn pjmt-cta-btn--solid" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="submissions"}">
				{translate key="plugins.themes.pjmt.submitPaper" default="Submit Your Paper"}
			</a>
			<a class="pjmt-cta-btn pjmt-cta-btn--outline" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="editorialTeam"}">
				{translate key="plugins.themes.pjmt.becomeReviewer" default="Become a Reviewer"}
			</a>
			<div class="pjmt-social">
				{if $currentContext->getData('facebookUrl')}<a href="{$currentContext->getData('facebookUrl')|escape}" target="_blank" rel="noopener noreferrer" aria-label="Facebook">F</a>{/if}
				{if $currentContext->getData('linkedinUrl')}<a href="{$currentContext->getData('linkedinUrl')|escape}" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">in</a>{/if}
				{if $currentContext->getData('twitterUrl')}<a href="{$currentContext->getData('twitterUrl')|escape}" target="_blank" rel="noopener noreferrer" aria-label="X">X</a>{/if}
			</div>

			<div class="pjmt-panel">
				<h3>{translate key="navigation.journalMenu" default="Journal Menu"}</h3>
				<ul class="pjmt-menu-list">
					<li><a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="editorialPolicies"}">{translate key="about.focusScope"|default="Focus & Scope"}</a></li>
					<li><a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="submissions"}">{translate key="about.submissions"}</a></li>
					<li><a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="information" op="authors"}">{translate key="plugins.themes.pjmt.manuscriptTemplate" default="Manuscript Template"}</a></li>
					<li><a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="editorialPolicies"}">{translate key="about.editorialPolicies"}</a></li>
					<li><a href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="editorialTeam"}">{translate key="about.editorialTeam"}</a></li>
				</ul>
			</div>

			{if $pjmtEditors}
				<div class="pjmt-panel">
					<h3>{translate key="about.editorialTeam"}</h3>
					{foreach from=$pjmtEditors item=editor}
						<div class="pjmt-board-member">
							<div class="name">{$editor.name|escape}</div>
							<div class="role">{$editor.role|escape}</div>
							{if $editor.affiliation}<div class="affil">{$editor.affiliation|escape}</div>{/if}
						</div>
					{/foreach}
					<a class="pjmt-board-link" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="editorialTeam"}">
						{translate key="plugins.themes.pjmt.viewBoard" default="View full editorial board"} &rarr;
					</a>
				</div>
			{else}
				<div class="pjmt-panel">
					<h3>{translate key="about.editorialTeam"}</h3>
					<a class="pjmt-board-link" href="{url router=\PKP\core\PKPApplication::ROUTE_PAGE page="about" op="editorialTeam"}">
						{translate key="plugins.themes.pjmt.viewBoard" default="View full editorial board"} &rarr;
					</a>
				</div>
			{/if}
		</aside>

	</div>
</main>

{include file="frontend/components/footer.tpl"}
