<?php

/**
 * @file plugins/themes/pjmt/PjmtThemePlugin.php
 *
 * Copyright (c) 2026 Presidential Graduate School
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @class PjmtThemePlugin
 * @ingroup plugins_themes_pjmt
 *
 * @brief PJMT theme for Open Journal Systems 3.5.0.
 *
 * Child theme built on top of OJS's default Bootstrap-based theme layer.
 * Adds a two-tier header (ISSN/login bar + main nav with logo), a hero +
 * three-column homepage layout, styled article "stat bar" (views / downloads
 * / citations), and Presidential Graduate School branding colours.
 */

namespace APP\plugins\themes\pjmt;

use APP\facades\Repo;
use APP\issue\Collector;
use PKP\config\Config;
use PKP\plugins\ThemePlugin;
use PKP\plugins\Hook;
use PKP\submission\PKPSubmission;

class PjmtThemePlugin extends ThemePlugin
{
    /**
     * Initialize the theme's styles, scripts, options and menu areas.
     */
    public function init()
    {
        // Theme colour options, editable from Website Settings > Appearance > Theme
        $this->addOption('primaryColour', 'FieldColor', [
            'label' => __('plugins.themes.pjmt.option.primaryColour.label'),
            'default' => '#2B3187', // Presidential navy
        ]);

        $this->addOption('accentColour', 'FieldColor', [
            'label' => __('plugins.themes.pjmt.option.accentColour.label'),
            'default' => '#F26722', // Presidential orange
        ]);

        $this->addOption('showArticleStats', 'FieldOptions', [
            'type' => 'radio',
            'label' => __('plugins.themes.pjmt.option.showArticleStats.label'),
            'options' => [
                ['value' => 'show', 'label' => __('plugins.themes.pjmt.option.showArticleStats.show')],
                ['value' => 'hide', 'label' => __('plugins.themes.pjmt.option.showArticleStats.hide')],
            ],
            'default' => 'show',
        ]);

        $primaryColour = $this->getSafeColour($this->getOption('primaryColour'), '#2B3187');
        $accentColour = $this->getSafeColour($this->getOption('accentColour'), '#F26722');

        // This theme uses plain CSS with custom properties (no LESS build step
        // required). We inject the two colour options as CSS variables via an
        // inline style block appended after the main stylesheet.
        $this->addMenuArea(['primary', 'user']);

        $this->addStyle('pjmtFonts', 'https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700;900&family=Inter:wght@400;500;600;700&display=swap');
        $this->addStyle('pjmtCss', 'resources/css/pjmt.css');
        $this->addStyle('pjmtColours', "
            :root {
                --pjmt-primary: $primaryColour;
                --pjmt-accent: $accentColour;
            }
        ", ['inline' => true]);

        $this->addScript('pjmtJs', 'resources/js/pjmt.js');

        // Styles for HTML galleys (article full-text reader), kept minimal
        $this->addStyle('pjmtGalleyCss', 'resources/css/pjmt.css', ['contexts' => 'htmlGalley']);

        Hook::add('TemplateManager::display', $this->addPjmtTemplateData(...));
        Hook::add('TemplateManager::display', $this->registerPjmtTemplateFunctions(...));
    }

    /**
     * Get the theme's display name, shown in Website Settings > Appearance.
     */
    public function getDisplayName(): string
    {
        return __('plugins.themes.pjmt.name');
    }

    /**
     * Get the theme's description, shown in Website Settings > Appearance.
     */
    public function getDescription(): string
    {
        return __('plugins.themes.pjmt.description');
    }

    /** @copydoc ThemePlugin::saveOption() */
    public function saveOption($name, $value, $contextId = null)
    {
        if (($name === 'primaryColour' || $name === 'accentColour') && !preg_match('/^#[0-9a-fA-F]{3,6}$/', (string) $value)) {
            $value = null;
        }
        parent::saveOption($name, $value, $contextId);
    }

    /**
     * Make sure a colour option value is a safe hex colour before it is
     * echoed back out into an inline <style> block.
     */
    protected function getSafeColour($value, string $default): string
    {
        if (is_string($value) && preg_match('/^#[0-9a-fA-F]{3,6}$/', $value)) {
            return $value;
        }
        return $default;
    }

    /**
     * Assign extra template variables the PJMT templates rely on:
     * - the current issue and up to 3 upcoming/older issues, for the homepage
     * - a flag for whether to show the article stats bar
     *
     * @param string $hookName
     * @param array $args
     */
    public function addPjmtTemplateData($hookName, $args)
    {
        $templateMgr = $args[0];
        $template = $args[1];

        $request = $this->getRequest();
        $context = $request->getContext();

        $templateMgr->assign([
            'pjmtShowArticleStats' => $this->getOption('showArticleStats') !== 'hide',
            'pjmtPluginPath' => $this->getPluginPath(),
        ]);

        if (!$context) {
            return false;
        }

        if ($template === 'frontend/pages/indexJournal.tpl') {
            $contextId = $context->getId();

            $currentIssue = Repo::issue()->getCurrent($contextId);

            $recentIssues = Repo::issue()->getCollector()
                ->filterByContextIds([$contextId])
                ->filterByPublished(true)
                ->limit(4)
                ->orderBy(Collector::ORDERBY_PUBLISHED_ISSUES)
                ->getMany();

            $olderIssues = [];
            foreach ($recentIssues as $issue) {
                if (!$currentIssue || $issue->getId() !== $currentIssue->getId()) {
                    $olderIssues[] = $issue;
                }
            }

            // Up to 4 most recently published articles across the journal,
            // for the "Latest Articles" feed on the homepage.
            $latestArticles = [];
            $submissions = Repo::submission()->getCollector()
                ->filterByContextIds([$contextId])
                ->filterByStatus([PKPSubmission::STATUS_PUBLISHED])
                ->orderBy(\PKP\submission\Collector::ORDERBY_DATE_PUBLISHED, \PKP\submission\Collector::ORDER_DIR_DESC)
                ->limit(4)
                ->getMany();

            foreach ($submissions as $submission) {
                $publication = $submission->getCurrentPublication();
                if (!$publication) {
                    continue;
                }

                $sectionTitle = '';
                $sectionId = $publication->getData('sectionId');
                if ($sectionId) {
                    $section = Repo::section()->get($sectionId, $contextId);
                    if ($section) {
                        $sectionTitle = $section->getLocalizedTitle();
                    }
                }

                $latestArticles[] = [
                    'submission' => $submission,
                    'publication' => $publication,
                    'sectionTitle' => $sectionTitle,
                    'authorString' => method_exists($publication, 'getAuthorString') ? $publication->getAuthorString() : '',
                    'urlPath' => $submission->getBestId(),
                ];
            }

            $templateMgr->assign([
                'pjmtCurrentIssue' => $currentIssue,
                'pjmtOlderIssues' => $olderIssues,
                'pjmtLatestArticles' => $latestArticles,
            ]);
        }

        return false;
    }

    /**
     * Register the `pjmt_item_active` Smarty function, used by header.tpl to
     * add an "active" class to the current page's nav item.
     *
     * @param string $hookName
     * @param array $args
     */
    public function registerPjmtTemplateFunctions($hookName, $args)
    {
        $templateMgr = $args[0];

        if (!isset($templateMgr->registered_plugins['function']['pjmt_item_active'])) {
            $templateMgr->registerPlugin('function', 'pjmt_item_active', [$this, 'isActiveItem']);
        }

        return false;
    }

    /**
     * Smarty function: returns ' active' if the given navigation menu item
     * points at the current page, otherwise ''.
     *
     * @param array $params
     * @param \Smarty_Internal_Template $smarty
     * @return string
     */
    public function isActiveItem($params, $smarty)
    {
        $navigationMenuItem = $params['item'] ?? null;
        if (!$navigationMenuItem) {
            return '';
        }

        $request = $this->getRequest();
        $currentUrl = $request->getCompleteUrl();

        if (method_exists($navigationMenuItem, 'getIsChildVisible') && $navigationMenuItem->getIsChildVisible()) {
            return '';
        }

        if (method_exists($navigationMenuItem, 'getUrl') && $navigationMenuItem->getUrl() === $currentUrl) {
            return ' active';
        }

        return '';
    }
}

if (!PKP_STRICT_MODE) {
    class_alias('\APP\plugins\themes\pjmt\PjmtThemePlugin', '\PjmtThemePlugin');
}
