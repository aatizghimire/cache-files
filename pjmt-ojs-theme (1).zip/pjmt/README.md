# PJMT — OJS 3.5.0 Theme

A custom theme plugin for Open Journal Systems 3.5.0, built for the
**Presidential Journal of Management and Technology (PJMT)**, Presidential
Graduate School, Kathmandu. Modelled on your mockups: a two-tier header
(ISSN + login bar, then logo/nav/search), a hero image with a three-column
homepage (Current Issue & News | Latest Articles | Submit/Review CTAs +
Journal Menu + Editorial Board), and a reskinned article page.

Built directly on top of OJS's built-in default theme, so submission
workflow, editor dashboards, and other plugins keep working exactly as
before — only the public-facing reader templates are touched.

## Installation

1. Unzip `pjmt-ojs-theme.zip`.
2. Copy the `pjmt` folder into `plugins/themes/` in your OJS installation, so
   you end up with `plugins/themes/pjmt/PjmtThemePlugin.php`.
3. In the OJS admin dashboard: **Website Settings → Appearance → Theme**,
   select **PJMT** and save.
4. Under **Website Settings → Setup → Appearance**, upload:
   - **Homepage image** — the hero banner (shown at the top of the homepage).
     If you skip this, the hero section is simply not shown.
   - **Page header logo image** — your journal's logo. If you skip this, the
     theme falls back to the bundled `assets/logo.png` (your Presidential
     Graduate School mark).
5. Clear the template cache if styles don't refresh: **Administration →
   Expire All Caches** (or delete `cache/t_compile/*` and `cache/t_cache/*`
   on the server).

## What's inside

```
pjmt/
├── PjmtThemePlugin.php        Theme class: styles, options, template hooks
├── version.xml                Plugin metadata (OJS 3.5.0)
├── index.php                  Plugin entry file
├── locale/en/locale.po        English UI strings for the theme's own settings
├── assets/logo.png            Fallback Presidential Graduate School logo
├── resources/
│   ├── css/pjmt.css           All theme styling (plain CSS, no build step)
│   └── js/pjmt.js             Mobile nav + search toggle
└── templates/frontend/
    ├── components/header.tpl  Two-tier header override
    ├── components/footer.tpl  Four-column footer override
    └── pages/indexJournal.tpl Homepage override (hero + 3-column layout)
```

Everything else (article/issue/archive pages, submission forms, editor
dashboards, etc.) uses OJS's default templates, restyled via CSS classes
targeting the default theme's markup (`.obj_article_details`, `.page_title`,
`.galleys_links`, etc.) — see the bottom third of `pjmt.css`.

## Theme settings

From **Website Settings → Appearance → Theme**, PJMT exposes:

- **Primary colour** — header/footer navy, headings (default `#2B3187`)
- **Accent colour** — buttons, tags, links (default `#F26722`)
- **Article stats bar** — show/hide toggle (currently just gates a CSS block;
  wire it to your usage-stats data if you enable the Usage Statistics plugin)

## Notes and things worth checking on your install

- **No build step required.** Unlike the official Pragma theme, this theme
  ships plain CSS/JS directly — you do not need Node, npm, or Gulp to use it.
- **Homepage article feed** pulls your 4 most recently published articles
  across the whole journal (not just the current issue), tagged with their
  section name. Colour-coding for tags is defined in `pjmt.css`
  (`.pjmt-tag--<section-slug>`) — add a rule per section name if you use
  sections beyond Technology/Management/Education Technology/Entrepreneurship.
- **Editorial Board box** on the homepage links to your About → Editorial
  Team page rather than pulling live names, to avoid guessing at your OJS
  version's exact user-group API. If you'd like live names pulled in, that's
  a small addition to `addPjmtTemplateData()` in `PjmtThemePlugin.php`.
- **Indexing links** in the footer (DOAJ/Crossref/Google Scholar/NepJOL) are
  static — edit the `<ul>` in `footer.tpl` to match reality.
- Because this theme overrides three core template files, **please test on
  a staging copy of your site first**, especially after any future OJS core
  upgrade — if PKP changes the underlying template structure, re-diff
  `header.tpl` / `footer.tpl` / `indexJournal.tpl` against the new core
  versions in `lib/pkp/templates/frontend/` and reconcile.

## Customizing colours further

Edit the CSS custom properties at the top of `resources/css/pjmt.css`
(`--pjmt-primary`, `--pjmt-accent`, `--pjmt-red`, `--pjmt-gold`,
`--pjmt-lavender`) — or just use the Primary/Accent colour pickers in the
theme's settings panel, which override the first two at runtime.
