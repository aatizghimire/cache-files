<?php

/**
 * @file plugins/themes/presidentialJournal/index.php
 *
 * Custom theme for Presidential Journal of Tech and Innovation
 * Presidential Graduate School (PGS)
 *
 * Based on Academic Free Theme (openjournaltheme.com)
 */

require_once('PresidentialThemePlugin.inc.php');

return new PresidentialThemePlugin();
