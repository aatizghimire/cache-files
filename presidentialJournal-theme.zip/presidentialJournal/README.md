# Presidential Journal Theme for OJS

**Custom OJS theme for the Presidential Journal of Tech and Innovation**  
Published by **Presidential Graduate School (PGS)**, Kathmandu, Nepal.

Based on the excellent [Academic Free Theme](https://github.com/openjournalteam/academicFree) (Bootstrap 3 / OJS 3.2+).

## Brand Identity

Extracted directly from the official Presidential Graduate School logo:

| Element              | Hex       | RGB              | Usage                          |
|----------------------|-----------|------------------|--------------------------------|
| Primary Blue         | `#2B3187` | 43, 49, 135      | Headers, nav, primary buttons  |
| Accent Orange        | `#F26722` | 242, 103, 34     | Hovers, highlights, borders    |
| Accent Red           | `#CB2026` | 203, 32, 38      | Supporting (GRADUATE SCHOOL)   |
| Gold                 | `#FFC316` | 255, 195, 22     | Logo diamond border, accents   |
| Tagline Blue         | `#8C89C2` | 140, 137, 194    | Secondary text                 |

**Tagline:** LEAD | INSPIRE | INNOVATE

## Features

- Fully responsive (Bootstrap 3)
- Official PGS logo integrated
- Brand-coloured header, navigation, buttons, footer and interactive states
- Clean academic typography suitable for a technology & innovation journal
- SEO-friendly and accessible base
- Easy colour overrides via Theme Settings (Primary + Accent)

## Installation

1. Download / clone this folder.
2. Rename the folder to `presidentialJournal` (if needed).
3. Upload the entire folder into your OJS installation:

```bash
cp -r presidentialJournal /path/to/ojs/plugins/themes/
```

4. In OJS Admin → **Website Settings → Appearance → Theme**:
   - Select **Presidential Journal Theme (PGS)**
   - Save
5. (Optional) Upload the logo again under **Website Settings → Appearance → Logo** if you want the journal logo to appear in the site header (the theme already ships the logo in `images/`).

## Recommended Settings

- **Header Style**: Presidential (Diamond / Brand)
- **Primary Brand Colour**: `#2B3187`
- **Accent Colour**: `#F26722`

## Files of Interest

- `styles/header/presidential.css` – header & navigation branding
- `styles/presidential.css` – global overrides (buttons, links, footer, cards)
- `images/logo.png` / `images/top_logo.png` – official logo
- `PresidentialThemePlugin.inc.php` – theme plugin class

## Credits

- Original Academic Free Theme © openjournaltheme.com (MIT / GPL compatible)
- Brand adaptation & colour system for Presidential Graduate School, 2026
- Logo © Presidential Graduate School

## License

GNU GPL v3 (same as the original Academic Free Theme and OJS itself).

---

**Presidential Graduate School**  
Thapagaun, New Baneshwor, Kathmandu, Nepal  
https://presidential.edu.np  
LEAD | INSPIRE | INNOVATE
