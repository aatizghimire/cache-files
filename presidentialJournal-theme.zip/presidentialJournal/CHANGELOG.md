# Changelog — Presidential Journal Theme

## 1.0.0.0 — 2026-08-20

- Initial release for Presidential Journal of Tech and Innovation
- Forked & rebranded from Academic Free Theme 3.3.x
- Integrated official Presidential Graduate School logo
- Applied brand colour palette (Blue #2B3187, Orange #F26722, Red #CB2026, Gold #FFC316)
- New header style `presidential` (diamond-inspired accents)
- Global overrides for buttons, links, panels, footer, cards and focus states
- Locale strings updated for PGS branding
- Theme credit in footer points to presidential.edu.np
